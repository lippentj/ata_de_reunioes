def sugestao():
    
    return 0 