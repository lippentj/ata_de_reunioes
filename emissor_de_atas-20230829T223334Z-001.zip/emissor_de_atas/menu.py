import cadastro, emitir_sugestao, concluir, consultar, relatorios

resposta = 's'
while resposta == 's':

    menu = '''[--------- EMISSÃO DE ATAS DE REUNIÃO -----------]
    \r]   [1] Emitir Ata        [
    \r]   [2] Emitir Sugestão   [
    \r]   [3] Concluir Ata      [
    \r]   [4] Consultar Ata     [ 
    \r]   [5] relatórios        [
    '''
    
    print(menu)
    opcao = int(input("Entre com uma opção: "))

    if opcao == 1:
        cadastro.emitir_ata()
    elif opcao == 2:
        emitir_sugestao.sugestao()
    elif opcao == 3:
        concluir.concluir()
    elif opcao == 4:
        consultar.consultar()
    elif opcao == 5:
        relatorios.relatorios()
    else:
        print("\nOpção inválida!")

resposta = input("\ndeseja continuar[s/n]").lower()