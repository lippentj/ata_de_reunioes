def consultar():
    return 0