import csv, os

def emitir_ata():
   ata = {}
   os.system('cls') or None
   print("<<<<<Emissão de Atas>>>>>")
   titulo = input("titulo: ")
   pauta = input("Pauta: ")
   descricao = input("Descricão: ")
   setor = input("setor: ")
   chave = input("chave: ")
   inicio = input("data de inicio: ")
   termino = input("data de termino: ")

   
   coluna = ['titulo','pauta','descricao','setor','chave','tipo']
   
   files_exists = os.path.isfile('atas.csv')
   with open ('atas.csv', 'a', newline='', encoding='utf-8') as atas_csv:
        cadastrar = csv.DictWriter(atas_csv, fieldnames=coluna, delimiter=';', lineterminator='\r\n')
        if not files_exists:
            cadastrar.writeheader()
        cadastrar.writerow({'titulo':titulo.title(), 'pauta':pauta.title(), 'descricao':descricao.title(), 'setor':setor.title(),'inicio':inicio, 'termino':termino, 'chave':chave})
   print("!!!SALVO!!!")

dados = {}
os.system('cls') or None
print("<<<<Cadastro de Participantes>>>>")
matricula = input("\ndigite a numero da matricula: ")
nome = input("\nNome dos participantes: ")
dados[matricula] = [nome]
print(dados)
coluna = ['matricula','nome']

files_exists = os.path.isfile('participantes.csv')

with open ('participantes.csv', 'a', newline='', encoding='utf-8') as participantes_csv:
        cadastrar = csv.DictWriter(participantes_csv, fieldnames=coluna, delimiter=';', lineterminator='\r\n')
        if not files_exists:
            cadastrar.writeheader()
        cadastrar.writerow({'matricula':matricula, 'nome':nome.title()})
print("!!!SALVO!!!")
 

 
def cadastro_participantes():
   return 0