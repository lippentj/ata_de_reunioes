def relatorios():
    return 0