def concluir():
    return 0